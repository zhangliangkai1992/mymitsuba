./fontgen VeraMono.ttf VeraMono.png VeraMono.dsc 14
./bin2c VeraMono.png veramono14_png.h veramono14_png
./bin2c VeraMono.dsc veramono14_dsc.h veramono14_dsc

./fontgen Vera.ttf Vera.png Vera.dsc 14
./bin2c Vera.png vera14_png.h vera14_png
./bin2c Vera.dsc vera14_dsc.h vera14_dsc
