#!/bin/bash
strip -S Mitsuba.app/plugins/* Mitsuba.app/Contents/Frameworks/*.dylib Mitsuba.app/Contents/MacOS/* Mitsuba.app/python/*/*
