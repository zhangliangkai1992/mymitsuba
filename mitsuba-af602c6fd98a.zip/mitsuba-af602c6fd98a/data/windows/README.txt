This is the binary Windows release of Mitsuba, an extensible rendering framework.

Please use the 'mtsgui.exe' executable to launch the graphical user interface.

If you encounter an error message regarding a missing component named 'msvcr100.dll'
or 'msvcp100.dll', you will need to install the package "vcredist_2010_sp1_x86.exe'
or "vcredist_2010_sp1_x64.exe' (one of them will be included with the Mitsuba release)

For general documentation on Mitsuba, please refer to 
http://www.mitsuba-renderer.org/docs.html and 
http://www.mitsuba-renderer.org/videos.html.